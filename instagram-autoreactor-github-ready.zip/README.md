# Instagram Autoreactor (Android)

This is a Gradle-based Android project. The Android app uses an Accessibility Service to inspect visible Instagram DM UI and attempt to apply the selected reaction to a newly sent message. Instagram may change its UI, so runtime behavior must be tested on-device.

## Build with GitHub Actions

The workflow is `.github/workflows/android.yml`. It runs on pushes, pull requests, and manual dispatch. It uses JDK 17, Android SDK platform 37, Build Tools 36.0.0, and Gradle 9.6.0 (required by the Android Gradle Plugin 9.4.0). A successful run uploads the debug APK as the `instagram-autoreactor-debug-apk` artifact.

**Important:** when putting this project directly in a GitHub repository, upload the *contents* of this ZIP to the repository root, so `settings.gradle`, `build.gradle`, and `app/` are at the root. Do not leave everything inside an extra `instagram-autoreactor/` folder.

The same workflow also supports the fallback layout where the ZIP file named `instagram-autoreactor-github-ready.zip` is committed at the repository root, provided the workflow itself is installed at `.github/workflows/android.yml`.

## Local build

This project does not include the Gradle Wrapper. Install JDK 17, Gradle 9.6.0, and Android SDK platform 37 / Build Tools 36.0.0, then run `gradle --no-daemon clean assembleDebug` from the project root.

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions and privacy

The app does not request Instagram credentials or network access. Android Accessibility is a powerful permission: enable the service only after reviewing what it does, and keep control of the device and Instagram account.
